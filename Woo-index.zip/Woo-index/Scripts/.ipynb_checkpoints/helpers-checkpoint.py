import xml.etree.ElementTree as ET
import ujson
import requests
from bs4 import BeautifulSoup
from urllib.parse import unquote
import re



def TOOI_organisaties(normalizations, orgs = ['waterschappen', 'provincies', 'ministeries', 'gemeenten', 'zbo', 'overige_overheidsorganisaties']):
    
    data = {}
    
    for org in orgs:
        TOOI_reg_url = f"https://standaarden.overheid.nl/tooi/waardelijsten/work?work_uri=https%3A%2F%2Fidentifier.overheid.nl%2Ftooi%2Fset%2Frwp_{org}_peildatum"
        
        response = requests.get(TOOI_reg_url)
        soup = BeautifulSoup(response.text, 'html.parser')
    
        a_tag = soup.find('td', class_='align-center').find('a')
        href = a_tag['href']
    
        TOOI_file = unquote(href.split('=')[1])
        
        response = requests.get(TOOI_file)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table', class_='table table--condensed table__data-overview')
    
        if table:
            table_body = table.find('tbody')
        
            for row in table_body.find_all('tr'):
                columns = row.find_all('td')
                if columns:
                    if org == 'waterschappen':
                        if columns[3].text != '':
                            continue

                    value = re.sub(r'\s+', ' ', columns[1].strong.text)

                    if 'waterschap' in value and 'Limburg' not in value:
                        value = value.split('aterschap ')[1]
                    if 'ministerie van' in value:
                        value = value.split('inisterie van ')[1]

                    code = columns[0].a.text

                    value = value[0].upper() + value[1:]

                    if value in normalizations:
                        value = normalizations[value]
                    
                    data[value] = code

    return data



def download_latest_export00():
    
    # Download de recentste versie van het export00 bestand
    xml_url = 'https://organisaties.overheid.nl/archive/exportOO.xml'
    
    # Download de XML file
    response = requests.get(xml_url)
    xml_content = response.content
    
    # Save de XML File
    with open('exportOO_full.xml', 'wb') as file:
        file.write(xml_content)
    
    # Parse de XML file
    tree = ET.parse('exportOO_full.xml')
    root = tree.getroot()
    schema = str(root.tag.split('}')[0][1:])
    
    # Bepaal de namespaces
    namespaces = {
        "p":schema
    }

    return tree, namespaces




def xpath(element, path, namespaces):
    obj = element.find(path, namespaces)
    if obj is not None:
        if obj.text is not None:
            return obj.text
        else:
            return ''
    else:
        return ''




def update_woo_index(file_name, namespaces, tree, orgs):
    organisatie_elements = tree.findall(f'.//p:organisaties/p:organisatie', namespaces)
    
    final_list = []
    
    for organisatie in organisatie_elements:
        foi_documenten = []
        dc_publisher_name = xpath(organisatie, 'p:naam', namespaces)
        if dc_publisher_name in orgs:
        
            woo = organisatie.find(f'.//p:woo', namespaces)
            if woo:
                woo_info = woo.find(f'.//p:wooInformatie', namespaces)
                woo_index = woo.findall(f'.//p:wooIndex/p:documentLocatie', namespaces)
    
                for informatiecategorie in woo_index:       
                    foi_documenten.append({
                    "dc_title": xpath(informatiecategorie, 'p:informatiecategorie', namespaces),
                    "dc_source": xpath(informatiecategorie, 'p:url', namespaces),
                    "dc_type": "URL",
                    "foi_url_on_web": True,
                    "dc_description": xpath(informatiecategorie, 'p:toelichting', namespaces)
                    })
    
                if foi_documenten != []:
                    dict = {
                        "dc_identifier": f"nl.{orgs[dc_publisher_name]}.1e-i",
                        "dc_title": f"Locaties Woo-documenten {dc_publisher_name}",
                        "dc_type": "1e-i",
                        "dc_description": f"Locaties Woo-documenten {dc_publisher_name}",
                        "dc_source": f"{xpath(woo_info, 'p:urls/p:overzichtURL',namespaces)}#locaties-woo-documenten",
                        "dc_publisher": orgs[dc_publisher_name],
                        "dc_date_year": "2023",
                        "foi_files": {
                            "foi_documenten": foi_documenten
                        }
                    }
        
                    final_list.append(dict)
    
    with open(file_name, "w") as file:
        ujson.dump(final_list, file, indent = 4)
