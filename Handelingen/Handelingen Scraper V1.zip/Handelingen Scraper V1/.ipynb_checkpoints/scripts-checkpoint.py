import os
import gzip
from lxml import etree
from datetime import datetime, timedelta
from dateutil import parser
from lxml.etree import XMLSyntaxError
from gzip import BadGzipFile
import pandas as pd
import ujson
import xml.etree.ElementTree as ET
import time
import html

def handeling_scraper(sftp, item, start_date, end_date = datetime.now()):
    count = 0
        
    current_date = start_date
    total_days = (end_date - start_date).days

    while current_date <= end_date:
    
        date = current_date.strftime('%Y/%m/%d')
        print(date)
        
        if not os.path.exists(f'XML_documents_{item}'):
            os.makedirs(f'XML_documents_{item}')

        current_date += timedelta(days=1)
    
        directory_path = f"/{date}/{item}"

        try:
            directory_contents = sftp.listdir(directory_path)
        except FileNotFoundError:
            continue
        
        for content in directory_contents:
            count+=1
            download_xml_file(sftp, item, date, content)
        
    print(f"Downloaded files of {count} handelingen")



def bijlagen(bijlage_items, doc_list):

    for bijlage in bijlage_items:
        if '|' in bijlage:
            title, file_name = bijlage.split('|')
        else:
            title = bijlage
            file_name = bijlage
            
        doc_list.append({
        'dc_title': title,
        'dc_source': f"https://repository.officiele-overheidspublicaties.nl/externebijlagen/{file_name}/1/bijlage/{file_name}.pdf",
        'dc_type': 'bijlage',
        'foi_url_on_web': True
    })

    return doc_list


def extract_description(file_path):
    with gzip.open(file_path, 'rb') as gz_file:
        xml_content = gz_file.read()
        
        xml_string = xml_content.decode('utf-8')

        try:
            xml_tree = etree.XML(xml_content)
        except etree.XMLSyntaxError as e:
            return ''

        metadata_elements = xml_tree.xpath('//metadata')
        for metadata_element in metadata_elements:
            metadata_element.getparent().remove(metadata_element)

        body_text = etree.tostring(xml_tree, encoding='unicode')
        
        return body_text


def gather_metadata(filepath, organisaties, transformer, org_type = 'h'):
    Translatie_dict = {
                        "DC.title": "dc_title",
                        "DCTERMS.abstract":"dc_description",
                        "DCTERMS.available":"foi_publishedDate",
                        "OVERHEIDop.vergaderjaar":"dc_date_year",
                        "OVERHEIDop.Rubriek": "tooiwl_rubriek_code",
                        "OVERHEID.category": "tooiwl_topic",
                        "DC.identifier": "dc_source",
                        "OVERHEIDop.betreftRegeling": "foi_betreftRegeling",
                        "OVERHEIDop.startdatum": "foi_startDate",
                        "OVERHEIDop.einddatum": "foi_endDate",
                        "OVERHEIDop.publicationName" : 'dc_type',
                    }

    normalizations = {'Ministerie van Economische Zaken': 'Ministerie van Economische Zaken en Klimaat', 
        'Ministerie van Infrastructuur en Milieu': 'Ministerie van Infrastructuur en Waterstaat',
        'Ministerie van Verkeer en Waterstaat': 'Ministerie van Infrastructuur en Waterstaat',
        'Ministerie van Volkshuisvesting, Ruimtelijke Ordening en Milieubeheer': 'Ministerie van Binnenlandse Zaken en Koninkrijksrelaties',
        'Ministerie van Economische Zaken, Landbouw en Innovatie': 'Ministerie van Economische Zaken en Klimaat',
        "'s-Gravenhage": 'Den Haag', 'Bergen (Li)': 'Bergen (L)', 'Nederlandse Voedsel- en Warenautoriteit (NVWA)': 'Nederlandse Voedsel- en Warenautoriteit'}
    
    
    with open(filepath, 'r') as file:
        try:
            df= pd.read_xml(filepath, xpath=".//meta | .//metadata")
        except XMLSyntaxError:
            return None

    file_id = filepath.split('/')[1]
    without_suffix = file_id.split('.')[0]

    data_list = df[['name', 'scheme', 'content']].to_dict(orient='records')
        
    # Verwijder de soms bestaande bovenste None kolom
    data_list = [item for item in data_list if item['name'] is not None]

    # Er zijn vaak meerdere items genaamd DC.type om problemen te voorkomen hernoemen we deze items.
    for c,item in enumerate(data_list):
        if item['name'] == 'DC.type' and item['scheme'] in ['OVERHEID.Informatietype']:
            data_list[c]['name'] = item['scheme']
    
        if item['name'] == 'DC.type' and item['scheme'] == 'OVERHEIDop.HandelingTypen':
            data_list[c]['name'] = item['scheme']

        if item['name'] == 'DC.type' and item['scheme'] == 'OVERHEIDgvop.Informatietype':
            data_list[c]['name'] = item['scheme']

    # Zet de data in de wenselijke structuur (zonder het schema)
    data = {item['name']: item['content'] for item in data_list}
    
    
    if data['OVERHEID.organisationType'] == 'gemeente':
        placeholder = 'Gemeente '
    elif data['OVERHEID.organisationType'] == 'provincie':
        placeholder = 'Provincie '
    else:
        placeholder = ''

    if 'OVERHEIDop.datumVergadering' in data:
    
        date_object = parser.parse(data['OVERHEIDop.datumVergadering'])
        data['OVERHEIDop.datumVergadering'] = date_object.strftime("%Y-%m-%d")
    


    # Deze code zorgt ervoor dat alleen nog bestaande organisaties verzameld worden en dat hun TOOI code wordt verzameld
    if 'DC.creator' in data:
        
        if data['DC.creator'] in normalizations:
            data['DC.creator'] = normalizations[data['DC.creator']]
        if f"{placeholder}{data['DC.creator']}" not in organisaties.keys():
            return None
        else:
            data['dc_publisher'] = organisaties[f"{placeholder}{data['DC.creator']}"]
            data['DC.creator'] = f"{placeholder}{data['DC.creator']}"
    else:
        return None

    # Dit is de check voor metadata files, deze hebben uiteraard geen bodytext dus deze moet dan uit de normale file worden gehaald
    possible_file = f"XML_documents_{org_type}/{without_suffix}.xml.gz"
    if os.path.exists(possible_file):
        filepath = possible_file


    data['DC.identifier'] = f"https://zoek.officielebekendmakingen.nl/{without_suffix}"

    if 'OVERHEIDop.HandelingTypen' in data:
        doc_list = [{
            'dc_title': data['DC.title'],
            'dc_source': f"{data['DC.identifier']}.pdf",
            'dc_type': data['OVERHEIDop.HandelingTypen'],
            'foi_url_on_web': True,
        }]

    else:
        doc_list = [{
            'dc_title': data['DC.title'],
            'dc_source': f"{data['DC.identifier']}.pdf",
            'foi_sentDate': data['OVERHEIDop.datumVergadering'],
            'foi_url_on_web': True,
        }]


    if 'OVERHEID.category' in data:
        topics = [item['content'] for item in data_list if item['name'] == 'OVERHEID.category']
        topics = list(set(topics))
        data['OVERHEID.category'] = topics

    if 'OVERHEIDop.behandeldDossier' in data:
        dossiers = [f"https://zoek.officielebekendmakingen.nl/kst-{item['content'].replace(';', '-')}.html" for item in data_list if item['name'] == 'OVERHEIDop.behandeldDossier']
        data['OVERHEIDop.behandeldDossier'] = dossiers

    # Verzamel de bijlagen
    bijlage_items = [item['content'] for item in data_list if item['name'] == 'OVERHEIDop.externeBijlage']
    doc_list = bijlagen(bijlage_items, doc_list)
    
    if 'OVERHEIDop.terinzageleggingBG' in data:
        data['Test_Terinlagelegging'] = data['OVERHEIDop.terinzageleggingBG']

    if 'OVERHEIDop.paginareeks' in data:
        data['OVERHEIDop.pagina'] = data['OVERHEIDop.paginareeks']
    
    if "OVERHEIDop.pagina" in data and "OVERHEIDop.publicationIssue" in data:
        data['dc_externalIdentifier'] = f"{data['OVERHEIDop.publicationIssue']}-{data['OVERHEIDop.pagina']}"
        data['DC.title'] = f"Vergadering nr. {data['OVERHEIDop.publicationIssue']}, item {data['OVERHEIDop.pagina']} ({data['OVERHEIDop.vergaderjaar']}) - {data['DC.title']}"
        
    elif 'OVERHEIDop.handelingenItemNummer' in data and "OVERHEIDop.publicationIssue" in data:
        data['dc_externalIdentifier'] = f"{data['OVERHEIDop.publicationIssue']}-{data['OVERHEIDop.handelingenItemNummer']}"
        data['DC.title'] = f"Vergadering nr. {data['OVERHEIDop.publicationIssue']}, item {data['OVERHEIDop.handelingenItemNummer']} ({data['OVERHEIDop.vergaderjaar']}) - {data['DC.title']}"


    if 'DCTERMS.available' in data:
    
        date_object = parser.parse(data['DCTERMS.available'])
        data['DCTERMS.available'] = date_object.strftime("%Y-%m-%d")

        data['OVERHEIDop.vergaderjaar'] = data['DCTERMS.available'][:4]
        
    # data['foi_bodyText_schema'] = 'xml'

    # dom = xml.dom.minidom.parseString(foi_bodyText)
    # pretty_xml = dom.toprettyxml()
    # data['foi_bodyText'] = pretty_xml

    data["OVERHEIDop.publicationName"] = '2b'

    # Dit is de check voor metadata files, deze hebben uiteraard geen bodytext dus deze moet dan uit de normale file worden gehaald
    possible_file = f"XML_documents_{org_type}/{without_suffix}.xml.gz"
    if os.path.exists(possible_file):
        filepath = possible_file

    # Dat gebeurt hier, net als een mogelijke abstract
    html_bodyText = extract_description(filepath)
    doc_list[0]['foi_bodyTextHTML'] = html_bodyText

     # De attributen die mogelijk wat (schijf)ruimte kunnen kosten!
    data['foi_files'] = {'foi_documenten': doc_list}
    
    # Hernoem de attributen naar de wenselijke namen uit de translatie_dict
    renamed_data = {Translatie_dict[key] if key in Translatie_dict else key: value for key, value in data.items()}

    # Alle attributen die nu nog een punt in hun naam hebben worden verwijderd
    filtered_data = {key: value for key, value in renamed_data.items() if '.' not in key}

    return filtered_data




def update_json(filepath, json_dicts):
    if os.path.exists(filepath):
        with gzip.open(filepath, 'rt') as json_file:
            data = ujson.load(json_file)
    else:
        data = []

    for k, v in json_dicts.items():
        for i in v:
            data.append(i)

    with gzip.open(filepath, "wt") as json_file:
        ujson.dump(data, json_file, indent=4)


def replace_last_n_occurrences(text, old, new, n):
    indices = [i for i in range(len(text) - len(old) + 1) if text[i:i+len(old)] == old][-n:]
    
    for index in indices:
        text = text[:index] + new + text[index+len(old):]
    
    return text


def create_json_files(organisatietype, max_chunk_size, organisaties, transformer, heruitgaves):
    start_time = datetime.now()
    json_dicts = {}

    original_filepath = f'SFTP_handelingen_2b.json.gz'

    directory = f'XML_documents_{organisatietype}'
    for gz_filename in os.listdir(directory):

        if gz_filename.split('.', 1)[0] in heruitgaves:
            continue
        
        if 'metadata' not in gz_filename:
            file_id = gz_filename.split('.')
            possible_file = f"{directory}/{file_id[0]}.metadata.xml.gz"

            if not os.path.exists(possible_file):
                try:
                    metadata = gather_metadata(f"{directory}/{gz_filename}", organisaties, transformer)
                except (BadGzipFile, UnicodeDecodeError, TypeError, KeyError):
                    continue

        else:
            try:
                metadata = gather_metadata(f"{directory}/{gz_filename}", organisaties, transformer)
            except (BadGzipFile, UnicodeDecodeError, TypeError, KeyError):
                continue
    
  
        if metadata is not None:
            
            if 'dc_publisher' not in metadata:
                continue

            identifier, end_point = metadata['dc_source'].rsplit('-', 1)
            identifier = replace_last_n_occurrences(identifier, '-', '.', 2).split('/')[-1]
            id  = identifier.rsplit('.', 1)[1]
            
            
            identifier = f"nl.{metadata['dc_publisher']}.2b.{metadata['dc_date_year']}.{id}"

            if identifier not in json_dicts:
                json_dicts[identifier] = []


            json_dicts[identifier].append(metadata)
            metadata = None
                

    update_json(original_filepath, json_dicts)


def download_xml_file(sftp, item, date, content):
    start_time = datetime.now()
    directory_path = f"/{date}/{item}"
    new_path = f"{directory_path}/{content}"

    remote_metadata_path = new_path + '/metadata.xml'
    local_metadata_path = f'XML_documents_{item}/{content}.metadata.xml'
    local_xml_path = f'XML_documents_{item}/{content}.xml'
    
    try:
        if not os.path.exists(f'{local_metadata_path}.gz'):
            with sftp.file(remote_metadata_path, 'r') as remote_file:
                remote_file_content = remote_file.read()
    
            with gzip.open(local_metadata_path + '.gz', 'wb') as local_metadata_file:
                local_metadata_file.write(remote_file_content)

    except (FileNotFoundError, ET.ParseError) as e:
        pass
    
    try:
        if not os.path.exists(f'{local_xml_path}.gz'):
            with sftp.file(new_path + f'/{content}.xml', 'r') as remote_file2:
                remote_file_content2 = remote_file2.read()
    
            with gzip.open(local_xml_path + '.gz', 'wb') as local_xml_file:
                local_xml_file.write(remote_file_content2)

    except (FileNotFoundError, ET.ParseError) as e:
        pass



def handelingen_analysis():
    with gzip.open('SFTP_handelingen_2b.json.gz', 'rt') as json_file:
        data = ujson.load(json_file)
    
    df = pd.DataFrame(data)

    updated_files = 0
    files_without_bodytext = 0
    for k,v in df.iterrows():
        if '-n1' in v['dc_source']:
            updated_files += 1
        for i in v['foi_files']['foi_documenten']:
            if not i['foi_bodyTextHTML']:
                files_without_bodytext += 1
    
    print(f'aantal al "bestaande" handelingen met een vernieuwde versie: {updated_files}')
    print(f'aantal files zonder bodytext: {files_without_bodytext}')