import xml.etree.ElementTree as ET
import paramiko
import time
from lxml import etree
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from urllib.parse import urlparse, unquote
import ujson
from collections import defaultdict
import gzip
import shutil
import os
from threading import BoundedSemaphore
import random
from tqdm import tqdm
import zlib
import pandas as pd
import regex as re
import pyproj
from lxml.etree import XMLSyntaxError
from gzip import BadGzipFile
from dateutil import parser
import math
from unidecode import unidecode

def TOOI_organisaties(normalizations = {
    "Instituut Fysieke Veiligheid": "Nederlands Instituut Publieke Veiligheid",
    "Toelatingsorganisatie kwaliteitsborging bouw": "toelatingsorganisatie kwaliteitsborging bouw",
    "College van Afgevaardigden": "College van afgevaardigden",
    "Eerste Kamer": "Eerste Kamer der Staten-Generaal",
    "Tweede Kamer": "Tweede Kamer der Staten-Generaal",
    "ProRail": "ProRail B.V."
    }, orgs = ['waterschappen', 'provincies', 'ministeries', 'gemeenten', 'zbo', 'overige_overheidsorganisaties', 'samenwerkingsorganisaties']):
    
    data = {}
    
    for org in orgs:
        TOOI_reg_url = f"https://standaarden.overheid.nl/tooi/waardelijsten/work?work_uri=https%3A%2F%2Fidentifier.overheid.nl%2Ftooi%2Fset%2Frwp_{org}_peildatum"

        print(TOOI_reg_url)
        
        response = requests.get(TOOI_reg_url)
        soup = BeautifulSoup(response.text, 'html.parser')

        woos=re.findall(r'href="(.*?)"',str(soup))

        href = [u for u in woos if 'lijst_uri=' in u][0]
    
        TOOI_file = unquote(href.split('=')[1])
        
        response = requests.get(TOOI_file)
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table', class_='table--condensed')
    
        if table:
            table_body = table.find('tbody')
        
            for row in table_body.find_all('tr'):
                columns = row.find_all('td')
                if columns:
                    if org == 'waterschappen':
                        if columns[3].text != '':
                            continue

                    value = re.sub(r'\s+', ' ', columns[1].text)

                    code = columns[0].text

                    value = value[0].upper() + value[1:]

                    if value in normalizations:
                        value = normalizations[value]
                    
                    data[value] = code

    return data



def download_xml_file(sftp, item, date, content):
    start_time = datetime.now()
    directory_path = f"/{date}/{item}"
    new_path = f"{directory_path}/{content}"

    remote_metadata_path = new_path + '/metadata.xml'
    local_metadata_path = f'XML_documents_{item}/{content}.metadata.xml'
    local_xml_path = f'XML_documents_{item}/{content}.xml'
    

    try:
        if not os.path.exists(f'{local_metadata_path}.gz'):
            with sftp.file(remote_metadata_path, 'r') as remote_file:
                remote_file_content = remote_file.read()
    
            with gzip.open(local_metadata_path + '.gz', 'wb') as local_metadata_file:
                local_metadata_file.write(remote_file_content)

    except (FileNotFoundError, ET.ParseError) as e:
        pass
    
    try:
        if not os.path.exists(f'{local_xml_path}.gz'):
            with sftp.file(new_path + f'/{content}.xml', 'r') as remote_file2:
                remote_file_content2 = remote_file2.read()
    
            with gzip.open(local_xml_path + '.gz', 'wb') as local_xml_file:
                local_xml_file.write(remote_file_content2)

    except (FileNotFoundError, ET.ParseError) as e:
        pass


def beschikking_scraper(sftp, item, start_date, end_date = datetime.now()):
    count = 0
        
    current_date = start_date
    total_days = (end_date - start_date).days

    while current_date <= end_date:
    
        date = current_date.strftime('%Y/%m/%d')
        print(date)
        
        if not os.path.exists(f'XML_documents_{item}'):
            os.makedirs(f'XML_documents_{item}')

        current_date += timedelta(days=1)
    
        directory_path = f"/{date}/{item}"

        try:
            directory_contents = sftp.listdir(directory_path)
        except FileNotFoundError:
            continue
        
        for content in directory_contents:
            count+=1
            download_xml_file(sftp, item, date, content)
        
    print(f"Downloaded files of {count} beschikkingen")






def get_coordinates_from_point(point, transformer):
    """ Zet de vage coordinaten om naar de bekendere standaard """
    
    match = re.search(r'\(([^)]+)\)', point)

    if match:
        content_within_brackets = match.group(1)
        if len(content_within_brackets.split(' ')) == 2:
            x_rd, y_rd = content_within_brackets.split(' ')
        else:
            return ''
            
    lon, lat = transformer.transform(x_rd, y_rd)
    
    return f"({lon}, {lat})"


def gebiedsmarkeringen(data_list, transformer):
    Geo_locaties = []
    saved_data = ''
    index = -1
    
    for data in data_list:
    
        if data['name'] == 'OVERHEIDop.gebiedsmarkering':
            Geo_locaties.append({data['name']:data['content']})
            saved_data = data['name']
            index+=1
    
        else:
            if data['name'] == 'DC.title':
                break
            elif saved_data != '':
                if data['name'] == 'OVERHEIDop.geometrie':
                    if "POINT" in data['content']:
                        Geo_locaties[index]['kml_Point'] = data['content']
                        Geo_locaties[index]['kml_coordinates'] = get_coordinates_from_point(data['content'], transformer)
                    if "LINESTRING" in data['content']:
                        Geo_locaties[index]['kml_LineString'] = data['content']
                    if "POLYGON" in data['content']:
                        Geo_locaties[index]['kml_Polygon'] = data['content']
                else:
                    Geo_locaties[index][data['name']] = data['content']
    
    return Geo_locaties


def find_gebied_attributen(gebiedsmarkering):
    gebied_attributen = set(['DC.spatial', 'OVERHEIDop.postcodeHuisnummer', 'OVERHEIDop.straatnaam', 'OVERHEIDop.woonplaats'])
    for i in gebiedsmarkering:
        for k,v in i.items():
            gebied_attributen.add(k)

    return gebied_attributen


def rubrieken_TOOI():
    rubrieken_dict = dict()
    
    TOOI_rubrieken = "https://standaarden.overheid.nl/tooi/waardelijsten/expression?lijst_uri=https%3A%2F%2Fidentifier.overheid.nl%2Ftooi%2Fset%2Fscw_wep_rubrieksindeling%2F4"
            
    response = requests.get(TOOI_rubrieken)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    table = soup.find('table', class_='table--condensed')
    
    if table:
        table_body = table.find('tbody')
    
        for row in table_body.find_all('tr'):
            columns = row.find_all('td')
            value = columns[0].text
            key = (columns[1].text).split(' | ')
            if len(key) == 2:
                key_string = key[1]
            else:
                key_string = key[0]
    
            rubrieken_dict[key_string] = value
    
    return rubrieken_dict



def extract_description(file_path, title):
    with gzip.open(file_path, 'rb') as gz_file:
        xml_content = gz_file.read()
    
        root = etree.fromstring(xml_content)

        metadata = root.find(".//metadata")
        if metadata is not None:
            root.remove(metadata)
        
        XML = etree.tostring(root, encoding=str)

        body_text = root.xpath('//officiele-publicatie//text()')

        body_text = [item.strip() for item in body_text if item.strip()]

        desc_list = []
        
        for i in body_text[2:]:
            if desc_list == []:
                if i != title and len(i.split(' ')) > 8:
                    desc_list.append(i)
                    if i[-1] == '.':
                        break
                    else:
                        continue
            else:
                desc_list.append(i)
                if i[-1] == '.':
                    break
                else:
                    continue
                    
        if len(desc_list) == 1:
            return XML, desc_list[0]
        if len(desc_list) > 1:
            return XML, ' '.join(desc_list)

        else:
            return XML,''


def bijlagen(bijlage_items, doc_list):

    for bijlage in bijlage_items:
        print(bijlage)
        if '|' in bijlage:
            title, file_name = bijlage.split('|')
        else:
            title = bijlage
            file_name = bijlage

        if '.jpg' in title.lower():
            dc_source = f"https://repository.officiele-overheidspublicaties.nl/externebijlagen/{file_name}/1/bijlage/{file_name}.jpg"

        elif '.png' in title.lower():
            dc_source = f"https://repository.officiele-overheidspublicaties.nl/externebijlagen/{file_name}/1/bijlage/{file_name}.png"

        else:
            dc_source = f"https://repository.officiele-overheidspublicaties.nl/externebijlagen/{file_name}/1/bijlage/{file_name}.pdf"
            
        doc_list.append({
            'dc_title': title,
            'dc_source': dc_source,
            'dc_type': 'bijlage',
            'foi_url_on_web': True
        })

    return doc_list


def rubrieken(k):
    if 'beschikking' in k.lower() or 'vergunning' in k.lower():
        return '2k'
    elif k in ['algemeen verbindend voorschrift (verordening)', 'Overige besluiten van algemene strekking', 'beleidsregel','Beleidsregel', 'Beleidsregels', 'delegatie- of mandaatbesluit','bekendmaking aan de scheepvaart', 'algemeenverbindendverklaring van cao-bepalingen', 'gemeenschappelijke regeling', 'ruimtelijk plan of omgevingsdocument','verkeersbesluit of -mededeling', 'ander besluit van algemene strekking']:
        return 'Besluit van Algemene Strekking'
    elif 'plan' in k.lower() or 'verordening' in k.lower():
        return 'Besluit van Algemene Strekking'
    elif 'melding' in k.lower():
        return 'Melding'
    elif k in ['vergadering of stuk van het bestuur', 'verkiezingen', 'andere voorlichtingsinformatie', 'inspraak', 'openingstijden', 'afvalinzameling']:
        return 'Voorlichting'
    else:
        return 'Overige'



def gather_metadata(filepath, organisaties, rubrieken_dict, transformer, org_type):
    Translatie_dict = {
                        "DC.title": "dc_title",
                        "DCTERMS.abstract":"dc_description",
                        "DCTERMS.available":"foi_publishedDate",
                        "OVERHEIDop.jaargang":"dc_date_year",
                        "DC.creator": "dc_publisher_name",
                        "OVERHEIDop.Rubriek": "tooiwl_rubriek_code",
                        "OVERHEID.category": "tooiwl_topic",
                        "DC.identifier": "dc_source",
                        "OVERHEIDop.betreftRegeling": "foi_betreftRegeling",
                        "OVERHEIDop.startdatum": "foi_startDate",
                        "OVERHEIDop.einddatum": "foi_endDate",
                    }

    normalizations = {'Ministerie van Economische Zaken': 'Ministerie van Economische Zaken en Klimaat', 
        'Ministerie van Infrastructuur en Milieu': 'Ministerie van Infrastructuur en Waterstaat',
        'Ministerie van Verkeer en Waterstaat': 'Ministerie van Infrastructuur en Waterstaat',
        'Ministerie van Volkshuisvesting, Ruimtelijke Ordening en Milieubeheer': 'Ministerie van Binnenlandse Zaken en Koninkrijksrelaties',
        'Ministerie van Economische Zaken, Landbouw en Innovatie': 'Ministerie van Economische Zaken en Klimaat',
        "'s-Gravenhage": 'Den Haag', 'Bergen (Li)': 'Bergen (L)', 'Nederlandse Voedsel- en Warenautoriteit (NVWA)': 'Nederlandse Voedsel- en Warenautoriteit'}
    
    
    foi_bodytext = ''
    
    with open(filepath, 'r') as file:
        try:
            df= pd.read_xml(filepath, xpath=".//meta | .//metadata")
        except XMLSyntaxError:
            return None

    file_id = filepath.split('/')[1]
    without_suffix = file_id.split('.')[0]

    data_list = df[['name', 'scheme', 'content']].to_dict(orient='records')

    # Dealt met alle geodata
    gebiedsmarkering = gebiedsmarkeringen(data_list, transformer)
        
    # Verwijder de soms bestaande bovenste None kolom
    data_list = [item for item in data_list if item['name'] is not None]

    # Er zijn vaak meerdere items genaamd DC.type om problemen te voorkomen hernoemen we deze items.
    for c,item in enumerate(data_list):
        if item['name'] == 'DC.type' and item['scheme'] in ['OVERHEID.Informatietype']:
            data_list[c]['name'] = item['scheme']
    
        if item['name'] == 'DC.type' and item['scheme'] == 'OVERHEIDop.Rubriek':
            data_list[c]['name'] = item['scheme']

        if item['name'] == 'DC.type' and item['scheme'] == 'OVERHEIDgvop.Informatietype':
            data_list[c]['name'] = item['scheme']

    # Zet de data in de wenselijke structuur (zonder het schema)
    data = {item['name']: item['content'] for item in data_list}

    
    if data['OVERHEID.organisationType'] == 'gemeente':
        placeholder = 'Gemeente '
    elif data['OVERHEID.organisationType'] == 'provincie':
        placeholder = 'Provincie '
    else:
        placeholder = ''

    if 'DCTERMS.available' in data:
        date_object = parser.parse(data['DCTERMS.available'])
        data['DCTERMS.available'] = date_object.strftime("%Y-%m-%d")
        

    # Als er een regeling te vinden is in de metadata verzamelen we deze ook, maar moet deze welk linken naar de echte regeling
    if 'OVERHEIDop.betreftRegeling' in data:
        data['OVERHEIDop.betreftRegeling'] = f"https://lokaleregelgeving.overheid.nl/{data['OVERHEIDop.betreftRegeling'].replace('_','/')}"

    # Deze code is voor het juist classificeren van rubrieken. 
    if 'OVERHEIDop.Rubriek' in data:
        data['tooiwl_rubriek'] = data['OVERHEIDop.Rubriek']
        data['OVERHEIDop.Rubriek'] = rubrieken_dict[data['OVERHEIDop.Rubriek']]
    else:
        if 'OVERHEIDgvop.Informatietype' in data:
            data['tooiwl_rubriek'] = data['OVERHEIDgvop.Informatietype']
            
    if 'tooiwl_rubriek' in data:
        rubriek = rubrieken(data['tooiwl_rubriek'].lower())
        if rubriek != '2k': 
            return None
        data['dc_type'] = rubriek


    # Deze code zorgt ervoor dat alleen nog bestaande organisaties verzameld worden en dat hun TOOI code wordt verzameld
    if 'DC.creator' in data:
        
        if data['DC.creator'] in normalizations:
            data['DC.creator'] = normalizations[data['DC.creator']]
        if f"{placeholder}{data['DC.creator']}" not in organisaties.keys():
            return None
        else:
            data['dc_publisher'] = organisaties[f"{placeholder}{data['DC.creator']}"]
            data['DC.creator'] = f"{placeholder}{data['DC.creator']}"

    # Dit is de check voor metadata files, deze hebben uiteraard geen bodytext dus deze moet dan uit de normale file worden gehaald
    possible_file = f"XML_documents_{org_type}/{without_suffix}.xml.gz"
    if os.path.exists(possible_file):
        filepath = possible_file

    # Dat gebeurt hier, net als een mogelijke abstract
    foi_bodyText, dc_description = extract_description(filepath, data['DC.title'])

    data['DC.identifier'] = f"https://zoek.officielebekendmakingen.nl/{without_suffix}"
    
    # Deze abstract wordt wel alleen verzameld als er nog geen abstract bestaat
    if "DCTERMS.abstract" not in data:
        data['DCTERMS.abstract'] = dc_description

    doc_list = [{
        'dc_title': data['DC.title'],
        'dc_source': f"{data['DC.identifier']}.pdf",
        'dc_type': 'Officiële Publicatie',
        'foi_url_on_web': True,
    }]

    if 'OVERHEID.category' in data:
        topics = [item['content'] for item in data_list if item['name'] == 'OVERHEID.category']
        data['OVERHEID.category'] = topics

    # Verzamel de bijlagen
    bijlage_items = [item['content'] for item in data_list if item['name'] == 'OVERHEIDop.externeBijlage']
    doc_list = bijlagen(bijlage_items, doc_list)

    # De attributen die mogelijk wat (schijf)ruimte kunnen kosten!
    data['foi_files'] = {'foi_documenten': doc_list}
    data['foi_geoInfo'] = gebiedsmarkering

    if 'OVERHEIDop.terinzageleggingBG' in data:
        data['Test_Terinlagelegging'] = data['OVERHEIDop.terinzageleggingBG']
    
    # data['foi_bodyText_schema'] = 'xml'

    # dom = xml.dom.minidom.parseString(foi_bodyText)
    # pretty_xml = dom.toprettyxml()
    # data['foi_bodyText'] = pretty_xml
    
    # Hernoem de attributen naar de wenselijke namen uit de translatie_dict
    renamed_data = {Translatie_dict[key] if key in Translatie_dict else key: value for key, value in data.items()}

    # Alle attributen die nu nog een punt in hun naam hebben worden verwijderd
    filtered_data = {key: value for key, value in renamed_data.items() if '.' not in key}

    return filtered_data




def update_json(filepath, json_dicts):
    if os.path.exists(filepath):
        with gzip.open(filepath, 'rt') as json_file:
            data = ujson.load(json_file)
    else:
        data = []

    for k, v in json_dicts.items():
        for i in v:
            data.append(i)

    with gzip.open(filepath, "wt") as json_file:
        ujson.dump(data, json_file, indent=4)



def create_json_files(organisatietype, max_chunk_size, organisaties, rubrieken_dict, transformer):
    start_time = datetime.now()
    count=0
    chunks = 0
    json_dicts = {}

    filepath = f'SFTP_beschikkingen_{organisatietype}.json.gz'

    directory = f'XML_documents_{organisatietype}'
    for gz_filename in os.listdir(directory):
        
        if 'metadata' not in gz_filename:
            file_id = gz_filename.split('.')
            possible_file = f"{directory}/{file_id[0]}.metadata.xml.gz"
            if not os.path.exists(possible_file):
                try:
                    metadata = gather_metadata(f"{directory}/{gz_filename}", organisaties, rubrieken_dict, transformer, organisatietype)
                except (BadGzipFile, UnicodeDecodeError):
                    continue

        else:
            try:
                metadata = gather_metadata(f"{directory}/{gz_filename}", organisaties, rubrieken_dict, transformer,organisatietype)
            except (BadGzipFile, UnicodeDecodeError):
                continue
        
        if metadata is not None:
            identifier = f"nl.{metadata['dc_publisher']}.2k.{metadata['dc_date_year']}"
            
            if identifier not in json_dicts:
                json_dicts[identifier] = []


            json_dicts[identifier].append(metadata)
            metadata = None
                
    

    update_json(filepath, json_dicts)


def get_ids(x):
    hrefs = []
    url = f'https://zoek.officielebekendmakingen.nl/resultaten?svel=Publicatiedatum&svol=Aflopend&pg=1000&q=(c.product-area==%22officielepublicaties%22)and((dt.type==%22andere%20beschikking%22)or(dt.type==%22andere%20vergunning%22)or(dt.type==%22evenementenvergunning%22)or(dt.type==%22exploitatievergunning%22)or(dt.type==%22omgevingsvergunning%22)or(dt.type==%22vergunning%20voor%20activiteiten%20op%20of%20in%20oppervlaktewater%22))and(((w.publicatienaam==%22Tractatenblad%22))or((w.publicatienaam==%22Staatsblad%22))or((w.publicatienaam==%22Staatscourant%22))or((w.publicatienaam==%22Gemeenteblad%22))or((w.publicatienaam==%22Provinciaal%20blad%22))or((w.publicatienaam==%22Waterschapsblad%22))or((w.publicatienaam==%22Blad%20gemeenschappelijke%20regeling%22)))%20AND%20w.publicatienaam==%22Staatscourant%22&zv=&col=&pagina={x}'
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'lxml')
        download_links = soup.find_all('a', class_='icon--download')
        for link in download_links:
            hrefs.append(link.get('href').split('.pdf')[0])
        return hrefs
    else:
        return []



def find_ceil(url):
    """ Vind het aantal pagina's wat nodig zijn om alle documenten van een bepaalde organisatie op te halen """
    
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    amount = soup.find('span', class_='h1__sub')

    if not amount:
        return 0
    
    matches = re.search(r'(\d+) van de (\d+) resultaten', amount.text)
    
    if matches:
        x = matches.group(1)
        y = matches.group(2)
        pages = math.ceil(int(y) / int(x))
        return pages
