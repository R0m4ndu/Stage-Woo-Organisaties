import os
import pandas as pd
import json

def statistics(Organisatie):
    
    if (os.path.exists(f"Files/Json/Medewerkers/Personen/{Organisatie}.json")) == False:
        return None
    
    with open(f"Files/Json/Medewerkers/Personen/{Organisatie}.json", "r") as file:
        json_data = json.load(file)
        
    
    identifiers = list(json_data[0]['infobox']['foi_dossiers']['0'].keys())
    id_dict = {item: 0 for item in identifiers}
    
    for dct in json_data:
        for k,v in dct['infobox']['foi_dossiers'].items():
            for ID in identifiers:
                if v[ID] != '':
                    id_dict[ID] += 1
                        
                        
                        
    Max = id_dict['dc_identifier']
    Keep = ['foaf_firstName', 'foi_linkedin', 'foi_twitter', 'foi_wikipedia', 'foaf_workplaceHomepage']
            
    filtered_dict = {'Total': Max}

    for k, v in id_dict.items():
        if k in Keep:
            filtered_dict[k] = v

    return filtered_dict




def org_stats():
    if (os.path.exists(f"Files/Json/Organisaties/alle_TOOI_organisaties.json")) == False:
        return None
    
    with open(f"Files/Json/Organisaties/alle_TOOI_organisaties.json", "r") as file:
        json_data = json.load(file)
        
    
    identifiers = list(json_data['infobox']['foi_dossiers']['0'].keys())
    id_dict = {item: 0 for item in identifiers}
    
    for k,v in json_data['infobox']['foi_dossiers'].items():
        for ID in identifiers:
            if v[ID] != '':
                if v['dc_publisher'] != '':
                    id_dict[ID] += 1
                        
                        
                        
    Max = id_dict['dc_identifier']
    Keep = ['foi_linkedin', 'foi_twitter', 'foi_wikipedia', 'foi_Woo_URL']
            
    filtered_dict = {'Total': Max}

    for k, v in id_dict.items():
        if k in Keep:
            filtered_dict[k] = v

    df = pd.DataFrame(columns=['Totaal', 'Linkedin', 'Twitter', 'Wikipedia', 'Woo-Pagina'])
    df.loc['Organisaties'] = filtered_dict.values()
    
    return df