import requests
from bs4 import BeautifulSoup
import regex as re
from urllib.parse import urlparse, unquote
from datetime import datetime
import pandas as pd
from io import StringIO
import numpy as np
import copy

def TOOI_organisaties(normalizations = {
    "Instituut Fysieke Veiligheid": "Nederlands Instituut Publieke Veiligheid",
    "Toelatingsorganisatie kwaliteitsborging bouw": "toelatingsorganisatie kwaliteitsborging bouw",
    "College van Afgevaardigden": "College van afgevaardigden",
    "Eerste Kamer": "Eerste Kamer der Staten-Generaal",
    "Tweede Kamer": "Tweede Kamer der Staten-Generaal",
    "ProRail": "ProRail B.V."
    }, orgs = ['waterschappen', 'provincies', 'ministeries', 'gemeenten', 'zbo', 'overige_overheidsorganisaties', 'samenwerkingsorganisaties']):
    
    data = {}
    
    for org in orgs:
        TOOI_reg_url = f"https://standaarden.overheid.nl/tooi/waardelijsten/work?work_uri=https%3A%2F%2Fidentifier.overheid.nl%2Ftooi%2Fset%2Frwp_{org}_peildatum"

        print(TOOI_reg_url)
        
        response = requests.get(TOOI_reg_url)
        soup = BeautifulSoup(response.text, 'html.parser')

        woos=re.findall(r'href="(.*?)"',str(soup))

        href = [u for u in woos if 'lijst_uri=' in u][0]
    
        TOOI_file = unquote(href.split('=')[1])
        
        response = requests.get(TOOI_file)
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        table = soup.find('table', class_='table--condensed')
    
        if table:
            table_body = table.find('tbody')
        
            for row in table_body.find_all('tr'):
                columns = row.find_all('td')
                if columns:
                    if org == 'waterschappen':
                        if columns[3].text != '':
                            continue

                    value = re.sub(r'\s+', ' ', columns[1].text)

                    code = columns[0].text

                    value = value[0].upper() + value[1:]

                    if value in normalizations:
                        value = normalizations[value]
                    
                    data[value] = code

    return data


def get_results_documenten(ori_id, amount, start_date, doc_type, last_discussed=True, id_list = []):
    # URL and headers
    
    url = "https://api.openraadsinformatie.nl/v1/elastic/ori_*/_search?"
    headers = {
        "Content-Type": "application/json"
    }
    
    # Request JSON data
    data = {
        "query": {
            "bool": {
                "must": [
                    {
                        "simple_query_string": {
                            "fields": ["text", "title", "description", "name"],
                            "default_operator": "or",
                            "query": "*"
                        }
                    },
                    {
                        "terms": {
                            "_index": [ori_id],
                        }
                    },
                    {
                        "match": {
                            "@type": doc_type,
                        }
                    }
                ]
            }
        },
        "size": amount,
        "_source": {
            "includes": ["*"],
            "excludes": []
        },
        "from": 0,
        "sort": [
            {
                "last_discussed_at": {
                    "order": "asc"
                }
            }
        ],
    }

    # If last_discussed is provided, add the range part to the query
    if last_discussed == True:
        data["query"]["bool"]["must"].append({
            "range": {
                "last_discussed_at": {
                    "gte": start_date,
                    "lte": f"2024-12-31T23:59:59+02:00",
                }
            }
        })

    if id_list:
        data["query"]["bool"]["must"].append({
            "terms": {
                "_id": id_list
            }
        })

    # Send the POST request
    response = requests.post(url, json=data, headers=headers)
    
    # Check the response
    if response.status_code == 200:
        result = response.json()
        return result
    else:
        print("Request failed with status code:", response.status_code)
        print("Response content:", response.text)


def process_report(id, all_results, all_agendapunten, all_attachments, meeting_number, organisaties, org_dict, invitees):
    final_list = []

    json_data = {}

    total_len = 0
    
    data = all_results[id]

    title = data['_source']['name']

    json_data['dc_source'] = data['_source']['organization']
    
    # invitees_list = []
    # try:
    #     invitees = data['_source']['invitee']
    #     if isinstance(invitees, str):
    #         invitees = [invitees]

    #     json_data['foi_invitees'] = [all_results[invitee]['_source']['name'] for invitee in invitees]
    # except KeyError:
    #     pass


    gemeente_placeholder = org_dict[data['_source']['organization']].lower().split(' ',1)[1].replace('-','').replace(' ','')
    
    if 'nuenen,gerwenennederwetten' in gemeente_placeholder:
        gemeente_placeholder = 'nuenen'

    if 'pijnackernootdorp' in gemeente_placeholder:
        gemeente_placeholder = 'pijnacker-nootdorp'


    if data['_source']['was_generated_by']['original_identifier'].isdigit():
        json_data['dc_source'] = f"https://{gemeente_placeholder}.notubiz.nl/vergadering/{data['_source']['was_generated_by']['original_identifier']}"
    else:
        json_data['dc_source'] = f"https://{gemeente_placeholder}.bestuurlijkeinformatie.nl/Agenda/Index/{data['_source']['was_generated_by']['original_identifier']}"
    
    json_data['dc_type'] = '2b'   

    try:
        json_data['dc_publisher'] = organisaties[org_dict[data['_source']['organization']].replace('Bergen NH', 'Bergen (NH)')]
    except KeyError:
        return ''
    try:
        json_data['foi_chair'] = data['_source']['chair']
    except KeyError:
        pass
    try:
        json_data['foi_committee'] = all_results[data['_source']['committee']]['_source']['name']
    except KeyError:
        pass
    try:
        json_data['foi_location'] = data['_source']['location']
    except KeyError:
        pass
    

    try:
        json_data['foi_publishedDate'] = datetime.fromisoformat(data['_source']['start_date']).strftime('%Y-%m-%d')

    except KeyError:
        json_data['foi_publishedDate'] = datetime.fromisoformat(data['_source']['was_generated_by']['started_at_time']).strftime('%Y-%m-%d')

    json_data['dc_date_year'] = json_data['foi_publishedDate'][:4]
    
    try:
        invits = [invitees[i]['_source']['name'] for i in data['_source']['invitee']]
        json_data['foi_invitees'] = invits
    except KeyError:
        pass

    agendapunt_number = 1

    agenda = []
    
    if 'agenda' in data['_source']:
    
        agendapunten = data['_source']['agenda']['@list']

        for agendapunt in agendapunten:
            agenda = []
            
            try:
                agenda_data = all_agendapunten[agendapunt]
            except KeyError:
                continue
            
            agendapunt_name = agenda_data['_source']['name']

            json_data['dc_title'] = f"{title} {json_data['foi_publishedDate']} - {agendapunt_name}"
            json_data['dc_description'] = f"Vergadering van de {org_dict[data['_source']['organization']]} op {json_data['foi_publishedDate']}. Onderdeel: {agendapunt_name}"
            json_data['dc_externalIdentifier'] = f"{meeting_number}-{agendapunt_number}"

            agendapunt_number+=1

            if 'attachment' in agenda_data['_source']:
        
                attachments = agenda_data['_source']['attachment']
                if isinstance(attachments, str):
                    attachments = [attachments]
            
                for a in attachments:

                    try:
                        tempdata = all_attachments[a]
                    except KeyError:
                        tempdata = []
                        
                    if tempdata:
                        temp_data = {}
                        try:
                            temp_data['dc_title'] = tempdata['_source']['name']
                            temp_data['dc_type'] = tempdata['_source']['@type']
                            temp_data['dc_source'] = tempdata['_source']['original_url']
                        except KeyError:
                            continue
                        # temp_data['dc_format'] = tempdata['_source']['content_type']
                        try:
                            bodytext = [txt for txt in tempdata['_source']['text'] if txt != '\x0c']
                            temp_data['foi_bodyText'] = bodytext
                        except KeyError:
                            temp_data['foi_bodyText'] = []
                        agenda.append(temp_data)

        
            json_data['foi_files'] = agenda
            final_list.append(copy.deepcopy(json_data))

            
            
    else:
        if 'attachment' in data['_source']:
        
            attachments = data['_source']['attachment']
            if isinstance(attachments, str):
                attachmeitemnts = [attachments]
        
            for a in attachments:
                temp_data = []

                json_data['dc_title'] = f"{title} Samenvatting & Collectie - {json_data['foi_publishedDate']}"
                json_data['dc_description'] = f"Vergadering van de {org_dict[data['_source']['organization']]} op {json_data['foi_publishedDate']}. Onderdeel: Samenvatting & Collectie"
                json_data['dc_externalIdentifier'] = f"{meeting_number}-{agendapunt_number}"
            
                try:
                    tempdata = all_attachments[a]
                except KeyError:
                    tempdata = []
    
                if tempdata:
                    temp_data = {}
                    try:
                        temp_data['dc_title'] = tempdata['_source']['name']
                        temp_data['dc_type'] = tempdata['_source']['@type']
                        temp_data['dc_source'] = tempdata['_source']['original_url']
                    except KeyError:
                        continue
                    # temp_data['dc_format'] = tempdata['_source']['content_type']
                    try:
                        bodytext = [txt for txt in tempdata['_source']['text'] if txt != '\x0c']
                        temp_data['foi_bodyText'] = bodytext
                    except KeyError:
                        temp_data['foi_bodyText'] = []
                    
                    # total_len += len(bodytext)
                agenda.append(temp_data)

        else:
            json_data['dc_title'] = f"{title} op {json_data['foi_publishedDate']}"
            json_data['dc_externalIdentifier'] = f"{meeting_number}-{agendapunt_number}"
            

        json_data['foi_files'] = agenda

        final_list.append(json_data)
        


    
    return total_len, final_list




def create_dataframe(all_results, all_agendapunten, all_attachments, org_id, organisaties):

    if org_id != '*':
        org_id = org_id.replace('_ad_', '_aan_den_')
        print(org_id)
        org_id = org_id.split('_', 1)[1]
        org_id = org_id.rsplit('_', 1)[0]
        org_id = org_id.replace('_', '')
        org_id = org_id.replace('-', '')
    
    all_result_list = []

    meeting_number = 0

    ID_list = set([v['_source']['organization'] for k,v in all_results.items()])
    
    orgs = items_off_ids("*", ID_list, 'Organization')

    org_dict = {k: v['_source']['name'] for k, v in orgs.items()}

    invitees_set = set()

    for k,v in all_results.items():

        try:
            invitees = v['_source']['invitee']
            if isinstance(invitees, str):
                invitees = [invitees]

            for i in invitees:
                invitees_set.add(i)


        
        except KeyError:
            pass

    Invites = items_off_ids("*", invitees_set, 'Person')
    
    for k,v in all_results.items():
        
        if v['_source']['@type'] == 'Meeting':

                meeting_number+=1

                try: 
                    length, x = process_report(k, all_results, all_agendapunten, all_attachments, meeting_number, organisaties, org_dict, Invites)
                except ValueError:
                    continue
            
                for i in x:
                    all_result_list.append(i)
            
    return all_result_list


def items_off_ids(ori_id, id_list, type):
    ids = len(id_list)
    identifier = 0
    all_items = {}
    
    
    
    while ids > 0:
        reports = get_results_documenten(ori_id, 10000, None, type, False, list(id_list)[identifier:identifier+10000])
        for r in reports['hits']['hits']:
            if r['_id'] not in all_items:
                all_items[r['_id']] = r
    
        ids = ids-10000
        identifier = identifier+10000
    
    
    print(len(all_items))
    return all_items


def find_attachment_ids(all_agendapunten, all_results):
    attachment_ids = set()
    
    for k,v in all_agendapunten.items():
        if 'attachment' in v['_source']:
            if isinstance(v['_source']['attachment'], str):
                attachments = [v['_source']['attachment']]
            else:
                attachments = v['_source']['attachment']
            for ap in attachments:
                attachment_ids.add(ap)
    
    for k,v in all_results.items():
        if 'attachment' in v['_source']:
            if isinstance(v['_source']['attachment'], str):
                attachments = [v['_source']['attachment']]
            else:
                attachments = v['_source']['attachment']
            for ap in attachments:
                attachment_ids.add(ap)

    print(len(attachment_ids))
    return attachment_ids

def update_column(i):
    try:
        soup = BeautifulSoup(i, 'html.parser')
        extracted_text = ''.join(soup.find_all(text=True))
        return extracted_text
        
    except TypeError: 
        return np.nan
    
    return attachment_ids